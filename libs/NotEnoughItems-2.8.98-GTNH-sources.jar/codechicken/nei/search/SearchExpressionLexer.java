// Generated from SearchExpressionLexer.g4 by ANTLR 4.13.2
package codechicken.nei.search;

// CHECKSTYLE:OFF
import codechicken.nei.SearchTokenParser;

import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class SearchExpressionLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		REGEX_LEFT=1, QUOTE_LEFT=2, DASH=3, RECIPE_INGREDIENTS=4, RECIPE_RESULT=5, 
		RECIPE_OTHERS=6, OR=7, LEFT_BRACKET=8, RIGHT_BRACKET=9, NEWLINE_OR_TAB=10, 
		SPACE=11, ESCAPED_SYMBOL=12, PREFIX=13, CLEAN_SYMBOL=14, REGEX_CONTENT=15, 
		REGEX_RIGHT=16, QUOTED_CONTENT=17, QUOTE_RIGHT=18;
	public static final int
		REGEX=1, QUOTED=2;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE", "REGEX", "QUOTED"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"REGEX_LEFT", "QUOTE_LEFT", "DASH", "RECIPE_INGREDIENTS", "RECIPE_RESULT", 
			"RECIPE_OTHERS", "OR", "LEFT_BRACKET", "RIGHT_BRACKET", "NEWLINE_OR_TAB", 
			"SPACE", "ESCAPED_SYMBOL", "PREFIX", "CLEAN_SYMBOL", "REGEX_CONTENT", 
			"REGEX_RIGHT", "QUOTED_CONTENT", "QUOTE_RIGHT"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, "'-'", null, null, null, "'|'", "'{'", "'}'", null, 
			"' '", null, null, null, null, "'/'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "REGEX_LEFT", "QUOTE_LEFT", "DASH", "RECIPE_INGREDIENTS", "RECIPE_RESULT", 
			"RECIPE_OTHERS", "OR", "LEFT_BRACKET", "RIGHT_BRACKET", "NEWLINE_OR_TAB", 
			"SPACE", "ESCAPED_SYMBOL", "PREFIX", "CLEAN_SYMBOL", "REGEX_CONTENT", 
			"REGEX_RIGHT", "QUOTED_CONTENT", "QUOTE_RIGHT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	private SearchTokenParser searchParser;

	public SearchExpressionLexer(CharStream input, SearchTokenParser searchParser) {
	    this(input);
	    this.searchParser = searchParser;
	}


	public SearchExpressionLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "SearchExpressionLexer.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	@Override
	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 12:
			return PREFIX_sempred((RuleContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean PREFIX_sempred(RuleContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return searchParser.hasRedefinedPrefix(getText().charAt(0));
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0000\u0012m\u0006\uffff\uffff\u0006\uffff\uffff\u0006\uffff\uffff"+
		"\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002\u0002\u0007\u0002"+
		"\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002\u0005\u0007\u0005"+
		"\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002\b\u0007\b\u0002"+
		"\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002\f\u0007\f\u0002"+
		"\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f\u0002\u0010"+
		"\u0007\u0010\u0002\u0011\u0007\u0011\u0001\u0000\u0003\u0000)\b\u0000"+
		"\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0003\u00038\b\u0003\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0003\u0004=\b\u0004\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005"+
		"B\b\u0005\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001\b\u0001"+
		"\b\u0001\t\u0001\t\u0001\t\u0001\t\u0001\n\u0001\n\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0001\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\u000e\u0001"+
		"\u000e\u0001\u000e\u0004\u000e[\b\u000e\u000b\u000e\f\u000e\\\u0001\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0010"+
		"\u0004\u0010f\b\u0010\u000b\u0010\f\u0010g\u0001\u0011\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0000\u0000\u0012\u0003\u0001\u0005\u0002\u0007\u0003"+
		"\t\u0004\u000b\u0005\r\u0006\u000f\u0007\u0011\b\u0013\t\u0015\n\u0017"+
		"\u000b\u0019\f\u001b\r\u001d\u000e\u001f\u000f!\u0010#\u0011%\u0012\u0003"+
		"\u0000\u0001\u0002\u0004\u0002\u0000\t\n\r\r\t\u0000  \"\"--//<<>>\\\\"+
		"^^{}\u0001\u0000//\u0001\u0000\"\"r\u0000\u0003\u0001\u0000\u0000\u0000"+
		"\u0000\u0005\u0001\u0000\u0000\u0000\u0000\u0007\u0001\u0000\u0000\u0000"+
		"\u0000\t\u0001\u0000\u0000\u0000\u0000\u000b\u0001\u0000\u0000\u0000\u0000"+
		"\r\u0001\u0000\u0000\u0000\u0000\u000f\u0001\u0000\u0000\u0000\u0000\u0011"+
		"\u0001\u0000\u0000\u0000\u0000\u0013\u0001\u0000\u0000\u0000\u0000\u0015"+
		"\u0001\u0000\u0000\u0000\u0000\u0017\u0001\u0000\u0000\u0000\u0000\u0019"+
		"\u0001\u0000\u0000\u0000\u0000\u001b\u0001\u0000\u0000\u0000\u0000\u001d"+
		"\u0001\u0000\u0000\u0000\u0001\u001f\u0001\u0000\u0000\u0000\u0001!\u0001"+
		"\u0000\u0000\u0000\u0002#\u0001\u0000\u0000\u0000\u0002%\u0001\u0000\u0000"+
		"\u0000\u0003(\u0001\u0000\u0000\u0000\u0005.\u0001\u0000\u0000\u0000\u0007"+
		"2\u0001\u0000\u0000\u0000\t7\u0001\u0000\u0000\u0000\u000b<\u0001\u0000"+
		"\u0000\u0000\rA\u0001\u0000\u0000\u0000\u000fC\u0001\u0000\u0000\u0000"+
		"\u0011E\u0001\u0000\u0000\u0000\u0013G\u0001\u0000\u0000\u0000\u0015I"+
		"\u0001\u0000\u0000\u0000\u0017M\u0001\u0000\u0000\u0000\u0019O\u0001\u0000"+
		"\u0000\u0000\u001bR\u0001\u0000\u0000\u0000\u001dU\u0001\u0000\u0000\u0000"+
		"\u001fZ\u0001\u0000\u0000\u0000!^\u0001\u0000\u0000\u0000#e\u0001\u0000"+
		"\u0000\u0000%i\u0001\u0000\u0000\u0000\')\u0005r\u0000\u0000(\'\u0001"+
		"\u0000\u0000\u0000()\u0001\u0000\u0000\u0000)*\u0001\u0000\u0000\u0000"+
		"*+\u0005/\u0000\u0000+,\u0001\u0000\u0000\u0000,-\u0006\u0000\u0000\u0000"+
		"-\u0004\u0001\u0000\u0000\u0000./\u0005\"\u0000\u0000/0\u0001\u0000\u0000"+
		"\u000001\u0006\u0001\u0001\u00001\u0006\u0001\u0000\u0000\u000023\u0005"+
		"-\u0000\u00003\b\u0001\u0000\u0000\u000045\u0005<\u0000\u000058\u0005"+
		"&\u0000\u000068\u0005<\u0000\u000074\u0001\u0000\u0000\u000076\u0001\u0000"+
		"\u0000\u00008\n\u0001\u0000\u0000\u00009:\u0005>\u0000\u0000:=\u0005&"+
		"\u0000\u0000;=\u0005>\u0000\u0000<9\u0001\u0000\u0000\u0000<;\u0001\u0000"+
		"\u0000\u0000=\f\u0001\u0000\u0000\u0000>?\u0005^\u0000\u0000?B\u0005&"+
		"\u0000\u0000@B\u0005^\u0000\u0000A>\u0001\u0000\u0000\u0000A@\u0001\u0000"+
		"\u0000\u0000B\u000e\u0001\u0000\u0000\u0000CD\u0005|\u0000\u0000D\u0010"+
		"\u0001\u0000\u0000\u0000EF\u0005{\u0000\u0000F\u0012\u0001\u0000\u0000"+
		"\u0000GH\u0005}\u0000\u0000H\u0014\u0001\u0000\u0000\u0000IJ\u0007\u0000"+
		"\u0000\u0000JK\u0001\u0000\u0000\u0000KL\u0006\t\u0002\u0000L\u0016\u0001"+
		"\u0000\u0000\u0000MN\u0005 \u0000\u0000N\u0018\u0001\u0000\u0000\u0000"+
		"OP\u0005\\\u0000\u0000PQ\t\u0000\u0000\u0000Q\u001a\u0001\u0000\u0000"+
		"\u0000RS\u0003\u001d\r\u0000ST\u0004\f\u0000\u0000T\u001c\u0001\u0000"+
		"\u0000\u0000UV\b\u0001\u0000\u0000V\u001e\u0001\u0000\u0000\u0000W[\b"+
		"\u0002\u0000\u0000XY\u0005\\\u0000\u0000Y[\u0005/\u0000\u0000ZW\u0001"+
		"\u0000\u0000\u0000ZX\u0001\u0000\u0000\u0000[\\\u0001\u0000\u0000\u0000"+
		"\\Z\u0001\u0000\u0000\u0000\\]\u0001\u0000\u0000\u0000] \u0001\u0000\u0000"+
		"\u0000^_\u0005/\u0000\u0000_`\u0001\u0000\u0000\u0000`a\u0006\u000f\u0003"+
		"\u0000a\"\u0001\u0000\u0000\u0000bf\b\u0003\u0000\u0000cd\u0005\\\u0000"+
		"\u0000df\u0005\"\u0000\u0000eb\u0001\u0000\u0000\u0000ec\u0001\u0000\u0000"+
		"\u0000fg\u0001\u0000\u0000\u0000ge\u0001\u0000\u0000\u0000gh\u0001\u0000"+
		"\u0000\u0000h$\u0001\u0000\u0000\u0000ij\u0005\"\u0000\u0000jk\u0001\u0000"+
		"\u0000\u0000kl\u0006\u0011\u0003\u0000l&\u0001\u0000\u0000\u0000\u000b"+
		"\u0000\u0001\u0002(7<AZ\\eg\u0004\u0005\u0001\u0000\u0005\u0002\u0000"+
		"\u0006\u0000\u0000\u0004\u0000\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}