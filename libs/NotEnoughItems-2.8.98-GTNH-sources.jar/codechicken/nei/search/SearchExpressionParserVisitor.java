// Generated from SearchExpressionParser.g4 by ANTLR 4.13.2
package codechicken.nei.search;

// CHECKSTYLE:OFF

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SearchExpressionParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SearchExpressionParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#recipeSearchExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecipeSearchExpression(SearchExpressionParser.RecipeSearchExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#recipeClauseExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRecipeClauseExpression(SearchExpressionParser.RecipeClauseExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#searchExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSearchExpression(SearchExpressionParser.SearchExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#orExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrExpression(SearchExpressionParser.OrExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#sequenceExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSequenceExpression(SearchExpressionParser.SequenceExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#unaryExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryExpression(SearchExpressionParser.UnaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#negateExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegateExpression(SearchExpressionParser.NegateExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#prefixedExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrefixedExpression(SearchExpressionParser.PrefixedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#token}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitToken(SearchExpressionParser.TokenContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#regex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRegex(SearchExpressionParser.RegexContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#quoted}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuoted(SearchExpressionParser.QuotedContext ctx);
	/**
	 * Visit a parse tree produced by {@link SearchExpressionParser#plainText}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlainText(SearchExpressionParser.PlainTextContext ctx);
}