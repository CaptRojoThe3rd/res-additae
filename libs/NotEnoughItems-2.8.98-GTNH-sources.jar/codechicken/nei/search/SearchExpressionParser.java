// Generated from SearchExpressionParser.g4 by ANTLR 4.13.2
package codechicken.nei.search;

// CHECKSTYLE:OFF

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class SearchExpressionParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		REGEX_LEFT=1, QUOTE_LEFT=2, DASH=3, RECIPE_INGREDIENTS=4, RECIPE_RESULT=5, 
		RECIPE_OTHERS=6, OR=7, LEFT_BRACKET=8, RIGHT_BRACKET=9, NEWLINE_OR_TAB=10, 
		SPACE=11, ESCAPED_SYMBOL=12, PREFIX=13, CLEAN_SYMBOL=14, REGEX_CONTENT=15, 
		REGEX_RIGHT=16, QUOTED_CONTENT=17, QUOTE_RIGHT=18;
	public static final int
		RULE_recipeSearchExpression = 0, RULE_recipeClauseExpression = 1, RULE_searchExpression = 2, 
		RULE_orExpression = 3, RULE_sequenceExpression = 4, RULE_unaryExpression = 5, 
		RULE_negateExpression = 6, RULE_prefixedExpression = 7, RULE_token = 8, 
		RULE_regex = 9, RULE_quoted = 10, RULE_plainText = 11;
	private static String[] makeRuleNames() {
		return new String[] {
			"recipeSearchExpression", "recipeClauseExpression", "searchExpression", 
			"orExpression", "sequenceExpression", "unaryExpression", "negateExpression", 
			"prefixedExpression", "token", "regex", "quoted", "plainText"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, "'-'", null, null, null, "'|'", "'{'", "'}'", null, 
			"' '", null, null, null, null, "'/'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "REGEX_LEFT", "QUOTE_LEFT", "DASH", "RECIPE_INGREDIENTS", "RECIPE_RESULT", 
			"RECIPE_OTHERS", "OR", "LEFT_BRACKET", "RIGHT_BRACKET", "NEWLINE_OR_TAB", 
			"SPACE", "ESCAPED_SYMBOL", "PREFIX", "CLEAN_SYMBOL", "REGEX_CONTENT", 
			"REGEX_RIGHT", "QUOTED_CONTENT", "QUOTE_RIGHT"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "SearchExpressionParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public SearchExpressionParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RecipeSearchExpressionContext extends ParserRuleContext {
		public List<RecipeClauseExpressionContext> recipeClauseExpression() {
			return getRuleContexts(RecipeClauseExpressionContext.class);
		}
		public RecipeClauseExpressionContext recipeClauseExpression(int i) {
			return getRuleContext(RecipeClauseExpressionContext.class,i);
		}
		public RecipeSearchExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_recipeSearchExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitRecipeSearchExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RecipeSearchExpressionContext recipeSearchExpression() throws RecognitionException {
		RecipeSearchExpressionContext _localctx = new RecipeSearchExpressionContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_recipeSearchExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(27);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 31102L) != 0)) {
				{
				{
				setState(24);
				recipeClauseExpression();
				}
				}
				setState(29);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RecipeClauseExpressionContext extends ParserRuleContext {
		public Token ingredientsPrefix;
		public Token resultPrefix;
		public Token othersPrefix;
		public SearchExpressionContext searchExpression() {
			return getRuleContext(SearchExpressionContext.class,0);
		}
		public TerminalNode RECIPE_INGREDIENTS() { return getToken(SearchExpressionParser.RECIPE_INGREDIENTS, 0); }
		public TerminalNode RECIPE_RESULT() { return getToken(SearchExpressionParser.RECIPE_RESULT, 0); }
		public TerminalNode RECIPE_OTHERS() { return getToken(SearchExpressionParser.RECIPE_OTHERS, 0); }
		public RecipeClauseExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_recipeClauseExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitRecipeClauseExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RecipeClauseExpressionContext recipeClauseExpression() throws RecognitionException {
		RecipeClauseExpressionContext _localctx = new RecipeClauseExpressionContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_recipeClauseExpression);
		try {
			setState(37);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RECIPE_INGREDIENTS:
				enterOuterAlt(_localctx, 1);
				{
				setState(30);
				((RecipeClauseExpressionContext)_localctx).ingredientsPrefix = match(RECIPE_INGREDIENTS);
				setState(31);
				searchExpression(0, ((RecipeClauseExpressionContext)_localctx).ingredientsPrefix.getText().length() > 1);
				}
				break;
			case RECIPE_RESULT:
				enterOuterAlt(_localctx, 2);
				{
				setState(32);
				((RecipeClauseExpressionContext)_localctx).resultPrefix = match(RECIPE_RESULT);
				setState(33);
				searchExpression(1, ((RecipeClauseExpressionContext)_localctx).resultPrefix.getText().length() > 1);
				}
				break;
			case RECIPE_OTHERS:
				enterOuterAlt(_localctx, 3);
				{
				setState(34);
				((RecipeClauseExpressionContext)_localctx).othersPrefix = match(RECIPE_OTHERS);
				setState(35);
				searchExpression(2, ((RecipeClauseExpressionContext)_localctx).othersPrefix.getText().length() > 1);
				}
				break;
			case REGEX_LEFT:
			case QUOTE_LEFT:
			case DASH:
			case LEFT_BRACKET:
			case SPACE:
			case ESCAPED_SYMBOL:
			case PREFIX:
			case CLEAN_SYMBOL:
				enterOuterAlt(_localctx, 4);
				{
				setState(36);
				searchExpression(3, false);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SearchExpressionContext extends ParserRuleContext {
		public int type;
		public boolean allRecipe;
		public OrExpressionContext orExpression() {
			return getRuleContext(OrExpressionContext.class,0);
		}
		public SearchExpressionContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public SearchExpressionContext(ParserRuleContext parent, int invokingState, int type, boolean allRecipe) {
			super(parent, invokingState);
			this.type = type;
			this.allRecipe = allRecipe;
		}
		@Override public int getRuleIndex() { return RULE_searchExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitSearchExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SearchExpressionContext searchExpression(int type,boolean allRecipe) throws RecognitionException {
		SearchExpressionContext _localctx = new SearchExpressionContext(_ctx, getState(), type, allRecipe);
		enterRule(_localctx, 4, RULE_searchExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(39);
			orExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OrExpressionContext extends ParserRuleContext {
		public List<SequenceExpressionContext> sequenceExpression() {
			return getRuleContexts(SequenceExpressionContext.class);
		}
		public SequenceExpressionContext sequenceExpression(int i) {
			return getRuleContext(SequenceExpressionContext.class,i);
		}
		public List<TerminalNode> OR() { return getTokens(SearchExpressionParser.OR); }
		public TerminalNode OR(int i) {
			return getToken(SearchExpressionParser.OR, i);
		}
		public OrExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitOrExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrExpressionContext orExpression() throws RecognitionException {
		OrExpressionContext _localctx = new OrExpressionContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_orExpression);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(41);
			sequenceExpression();
			setState(46);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(42);
					match(OR);
					setState(43);
					sequenceExpression();
					}
					} 
				}
				setState(48);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SequenceExpressionContext extends ParserRuleContext {
		public List<UnaryExpressionContext> unaryExpression() {
			return getRuleContexts(UnaryExpressionContext.class);
		}
		public UnaryExpressionContext unaryExpression(int i) {
			return getRuleContext(UnaryExpressionContext.class,i);
		}
		public List<TerminalNode> SPACE() { return getTokens(SearchExpressionParser.SPACE); }
		public TerminalNode SPACE(int i) {
			return getToken(SearchExpressionParser.SPACE, i);
		}
		public SequenceExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sequenceExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitSequenceExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SequenceExpressionContext sequenceExpression() throws RecognitionException {
		SequenceExpressionContext _localctx = new SequenceExpressionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_sequenceExpression);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(62); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(52);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==SPACE) {
						{
						{
						setState(49);
						match(SPACE);
						}
						}
						setState(54);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					setState(55);
					unaryExpression();
					setState(59);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
					while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
						if ( _alt==1 ) {
							{
							{
							setState(56);
							match(SPACE);
							}
							} 
						}
						setState(61);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
					}
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(64); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class UnaryExpressionContext extends ParserRuleContext {
		public TerminalNode LEFT_BRACKET() { return getToken(SearchExpressionParser.LEFT_BRACKET, 0); }
		public OrExpressionContext orExpression() {
			return getRuleContext(OrExpressionContext.class,0);
		}
		public TerminalNode RIGHT_BRACKET() { return getToken(SearchExpressionParser.RIGHT_BRACKET, 0); }
		public PrefixedExpressionContext prefixedExpression() {
			return getRuleContext(PrefixedExpressionContext.class,0);
		}
		public NegateExpressionContext negateExpression() {
			return getRuleContext(NegateExpressionContext.class,0);
		}
		public TokenContext token() {
			return getRuleContext(TokenContext.class,0);
		}
		public UnaryExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitUnaryExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryExpressionContext unaryExpression() throws RecognitionException {
		UnaryExpressionContext _localctx = new UnaryExpressionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_unaryExpression);
		try {
			setState(74);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LEFT_BRACKET:
				enterOuterAlt(_localctx, 1);
				{
				setState(66);
				match(LEFT_BRACKET);
				setState(67);
				orExpression();
				setState(69);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
				case 1:
					{
					setState(68);
					match(RIGHT_BRACKET);
					}
					break;
				}
				}
				break;
			case PREFIX:
				enterOuterAlt(_localctx, 2);
				{
				setState(71);
				prefixedExpression();
				}
				break;
			case DASH:
				enterOuterAlt(_localctx, 3);
				{
				setState(72);
				negateExpression();
				}
				break;
			case REGEX_LEFT:
			case QUOTE_LEFT:
			case ESCAPED_SYMBOL:
			case CLEAN_SYMBOL:
				enterOuterAlt(_localctx, 4);
				{
				setState(73);
				token('\0');
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NegateExpressionContext extends ParserRuleContext {
		public TerminalNode DASH() { return getToken(SearchExpressionParser.DASH, 0); }
		public UnaryExpressionContext unaryExpression() {
			return getRuleContext(UnaryExpressionContext.class,0);
		}
		public NegateExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_negateExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitNegateExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NegateExpressionContext negateExpression() throws RecognitionException {
		NegateExpressionContext _localctx = new NegateExpressionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_negateExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(76);
			match(DASH);
			setState(77);
			unaryExpression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PrefixedExpressionContext extends ParserRuleContext {
		public Character prefix;
		public Token prefixToken;
		public TokenContext token() {
			return getRuleContext(TokenContext.class,0);
		}
		public TerminalNode PREFIX() { return getToken(SearchExpressionParser.PREFIX, 0); }
		public PrefixedExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prefixedExpression; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitPrefixedExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrefixedExpressionContext prefixedExpression() throws RecognitionException {
		PrefixedExpressionContext _localctx = new PrefixedExpressionContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_prefixedExpression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			((PrefixedExpressionContext)_localctx).prefixToken = match(PREFIX);
			 ((PrefixedExpressionContext)_localctx).prefix =   ((PrefixedExpressionContext)_localctx).prefixToken.getText().charAt(0); 
			setState(81);
			token(_localctx.prefix);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TokenContext extends ParserRuleContext {
		public Character prefix;
		public RegexContext regex() {
			return getRuleContext(RegexContext.class,0);
		}
		public QuotedContext quoted() {
			return getRuleContext(QuotedContext.class,0);
		}
		public PlainTextContext plainText() {
			return getRuleContext(PlainTextContext.class,0);
		}
		public TokenContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public TokenContext(ParserRuleContext parent, int invokingState, Character prefix) {
			super(parent, invokingState);
			this.prefix = prefix;
		}
		@Override public int getRuleIndex() { return RULE_token; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitToken(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TokenContext token(Character prefix) throws RecognitionException {
		TokenContext _localctx = new TokenContext(_ctx, getState(), prefix);
		enterRule(_localctx, 16, RULE_token);
		try {
			setState(86);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case REGEX_LEFT:
				enterOuterAlt(_localctx, 1);
				{
				setState(83);
				regex(prefix);
				}
				break;
			case QUOTE_LEFT:
				enterOuterAlt(_localctx, 2);
				{
				setState(84);
				quoted(prefix);
				}
				break;
			case ESCAPED_SYMBOL:
			case CLEAN_SYMBOL:
				enterOuterAlt(_localctx, 3);
				{
				setState(85);
				plainText();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RegexContext extends ParserRuleContext {
		public Character prefix;
		public TerminalNode REGEX_LEFT() { return getToken(SearchExpressionParser.REGEX_LEFT, 0); }
		public TerminalNode REGEX_CONTENT() { return getToken(SearchExpressionParser.REGEX_CONTENT, 0); }
		public TerminalNode REGEX_RIGHT() { return getToken(SearchExpressionParser.REGEX_RIGHT, 0); }
		public RegexContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public RegexContext(ParserRuleContext parent, int invokingState, Character prefix) {
			super(parent, invokingState);
			this.prefix = prefix;
		}
		@Override public int getRuleIndex() { return RULE_regex; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitRegex(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RegexContext regex(Character prefix) throws RecognitionException {
		RegexContext _localctx = new RegexContext(_ctx, getState(), prefix);
		enterRule(_localctx, 18, RULE_regex);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(88);
			match(REGEX_LEFT);
			setState(89);
			match(REGEX_CONTENT);
			setState(91);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==REGEX_RIGHT) {
				{
				setState(90);
				match(REGEX_RIGHT);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class QuotedContext extends ParserRuleContext {
		public Character prefix;
		public TerminalNode QUOTE_LEFT() { return getToken(SearchExpressionParser.QUOTE_LEFT, 0); }
		public TerminalNode QUOTED_CONTENT() { return getToken(SearchExpressionParser.QUOTED_CONTENT, 0); }
		public TerminalNode QUOTE_RIGHT() { return getToken(SearchExpressionParser.QUOTE_RIGHT, 0); }
		public QuotedContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public QuotedContext(ParserRuleContext parent, int invokingState, Character prefix) {
			super(parent, invokingState);
			this.prefix = prefix;
		}
		@Override public int getRuleIndex() { return RULE_quoted; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitQuoted(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QuotedContext quoted(Character prefix) throws RecognitionException {
		QuotedContext _localctx = new QuotedContext(_ctx, getState(), prefix);
		enterRule(_localctx, 20, RULE_quoted);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(93);
			match(QUOTE_LEFT);
			setState(94);
			match(QUOTED_CONTENT);
			setState(96);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==QUOTE_RIGHT) {
				{
				setState(95);
				match(QUOTE_RIGHT);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PlainTextContext extends ParserRuleContext {
		public List<TerminalNode> CLEAN_SYMBOL() { return getTokens(SearchExpressionParser.CLEAN_SYMBOL); }
		public TerminalNode CLEAN_SYMBOL(int i) {
			return getToken(SearchExpressionParser.CLEAN_SYMBOL, i);
		}
		public List<TerminalNode> ESCAPED_SYMBOL() { return getTokens(SearchExpressionParser.ESCAPED_SYMBOL); }
		public TerminalNode ESCAPED_SYMBOL(int i) {
			return getToken(SearchExpressionParser.ESCAPED_SYMBOL, i);
		}
		public PlainTextContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_plainText; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SearchExpressionParserVisitor ) return ((SearchExpressionParserVisitor<? extends T>)visitor).visitPlainText(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PlainTextContext plainText() throws RecognitionException {
		PlainTextContext _localctx = new PlainTextContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_plainText);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(99); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(98);
					_la = _input.LA(1);
					if ( !(_la==ESCAPED_SYMBOL || _la==CLEAN_SYMBOL) ) {
					_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(101); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0012h\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0001"+
		"\u0000\u0005\u0000\u001a\b\u0000\n\u0000\f\u0000\u001d\t\u0000\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0003\u0001&\b\u0001\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0005\u0003-\b\u0003\n\u0003\f\u00030\t\u0003\u0001\u0004"+
		"\u0005\u00043\b\u0004\n\u0004\f\u00046\t\u0004\u0001\u0004\u0001\u0004"+
		"\u0005\u0004:\b\u0004\n\u0004\f\u0004=\t\u0004\u0004\u0004?\b\u0004\u000b"+
		"\u0004\f\u0004@\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005F\b\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005K\b\u0005\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007"+
		"\u0001\b\u0001\b\u0001\b\u0003\bW\b\b\u0001\t\u0001\t\u0001\t\u0003\t"+
		"\\\b\t\u0001\n\u0001\n\u0001\n\u0003\na\b\n\u0001\u000b\u0004\u000bd\b"+
		"\u000b\u000b\u000b\f\u000be\u0001\u000b\u0000\u0000\f\u0000\u0002\u0004"+
		"\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0000\u0001\u0002\u0000\f\f"+
		"\u000e\u000el\u0000\u001b\u0001\u0000\u0000\u0000\u0002%\u0001\u0000\u0000"+
		"\u0000\u0004\'\u0001\u0000\u0000\u0000\u0006)\u0001\u0000\u0000\u0000"+
		"\b>\u0001\u0000\u0000\u0000\nJ\u0001\u0000\u0000\u0000\fL\u0001\u0000"+
		"\u0000\u0000\u000eO\u0001\u0000\u0000\u0000\u0010V\u0001\u0000\u0000\u0000"+
		"\u0012X\u0001\u0000\u0000\u0000\u0014]\u0001\u0000\u0000\u0000\u0016c"+
		"\u0001\u0000\u0000\u0000\u0018\u001a\u0003\u0002\u0001\u0000\u0019\u0018"+
		"\u0001\u0000\u0000\u0000\u001a\u001d\u0001\u0000\u0000\u0000\u001b\u0019"+
		"\u0001\u0000\u0000\u0000\u001b\u001c\u0001\u0000\u0000\u0000\u001c\u0001"+
		"\u0001\u0000\u0000\u0000\u001d\u001b\u0001\u0000\u0000\u0000\u001e\u001f"+
		"\u0005\u0004\u0000\u0000\u001f&\u0003\u0004\u0002\u0000 !\u0005\u0005"+
		"\u0000\u0000!&\u0003\u0004\u0002\u0000\"#\u0005\u0006\u0000\u0000#&\u0003"+
		"\u0004\u0002\u0000$&\u0003\u0004\u0002\u0000%\u001e\u0001\u0000\u0000"+
		"\u0000% \u0001\u0000\u0000\u0000%\"\u0001\u0000\u0000\u0000%$\u0001\u0000"+
		"\u0000\u0000&\u0003\u0001\u0000\u0000\u0000\'(\u0003\u0006\u0003\u0000"+
		"(\u0005\u0001\u0000\u0000\u0000).\u0003\b\u0004\u0000*+\u0005\u0007\u0000"+
		"\u0000+-\u0003\b\u0004\u0000,*\u0001\u0000\u0000\u0000-0\u0001\u0000\u0000"+
		"\u0000.,\u0001\u0000\u0000\u0000./\u0001\u0000\u0000\u0000/\u0007\u0001"+
		"\u0000\u0000\u00000.\u0001\u0000\u0000\u000013\u0005\u000b\u0000\u0000"+
		"21\u0001\u0000\u0000\u000036\u0001\u0000\u0000\u000042\u0001\u0000\u0000"+
		"\u000045\u0001\u0000\u0000\u000057\u0001\u0000\u0000\u000064\u0001\u0000"+
		"\u0000\u00007;\u0003\n\u0005\u00008:\u0005\u000b\u0000\u000098\u0001\u0000"+
		"\u0000\u0000:=\u0001\u0000\u0000\u0000;9\u0001\u0000\u0000\u0000;<\u0001"+
		"\u0000\u0000\u0000<?\u0001\u0000\u0000\u0000=;\u0001\u0000\u0000\u0000"+
		">4\u0001\u0000\u0000\u0000?@\u0001\u0000\u0000\u0000@>\u0001\u0000\u0000"+
		"\u0000@A\u0001\u0000\u0000\u0000A\t\u0001\u0000\u0000\u0000BC\u0005\b"+
		"\u0000\u0000CE\u0003\u0006\u0003\u0000DF\u0005\t\u0000\u0000ED\u0001\u0000"+
		"\u0000\u0000EF\u0001\u0000\u0000\u0000FK\u0001\u0000\u0000\u0000GK\u0003"+
		"\u000e\u0007\u0000HK\u0003\f\u0006\u0000IK\u0003\u0010\b\u0000JB\u0001"+
		"\u0000\u0000\u0000JG\u0001\u0000\u0000\u0000JH\u0001\u0000\u0000\u0000"+
		"JI\u0001\u0000\u0000\u0000K\u000b\u0001\u0000\u0000\u0000LM\u0005\u0003"+
		"\u0000\u0000MN\u0003\n\u0005\u0000N\r\u0001\u0000\u0000\u0000OP\u0005"+
		"\r\u0000\u0000PQ\u0006\u0007\uffff\uffff\u0000QR\u0003\u0010\b\u0000R"+
		"\u000f\u0001\u0000\u0000\u0000SW\u0003\u0012\t\u0000TW\u0003\u0014\n\u0000"+
		"UW\u0003\u0016\u000b\u0000VS\u0001\u0000\u0000\u0000VT\u0001\u0000\u0000"+
		"\u0000VU\u0001\u0000\u0000\u0000W\u0011\u0001\u0000\u0000\u0000XY\u0005"+
		"\u0001\u0000\u0000Y[\u0005\u000f\u0000\u0000Z\\\u0005\u0010\u0000\u0000"+
		"[Z\u0001\u0000\u0000\u0000[\\\u0001\u0000\u0000\u0000\\\u0013\u0001\u0000"+
		"\u0000\u0000]^\u0005\u0002\u0000\u0000^`\u0005\u0011\u0000\u0000_a\u0005"+
		"\u0012\u0000\u0000`_\u0001\u0000\u0000\u0000`a\u0001\u0000\u0000\u0000"+
		"a\u0015\u0001\u0000\u0000\u0000bd\u0007\u0000\u0000\u0000cb\u0001\u0000"+
		"\u0000\u0000de\u0001\u0000\u0000\u0000ec\u0001\u0000\u0000\u0000ef\u0001"+
		"\u0000\u0000\u0000f\u0017\u0001\u0000\u0000\u0000\f\u001b%.4;@EJV[`e";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}